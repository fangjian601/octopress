/*
 * EDJoin.cpp
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#include <cmath>
#include <fstream>
#include "EDJoin.h"


EDJoin::EDJoin(char* file, int _t, int _q){
	t = _t;
	q = _q;
	readFromFile(file);
	step1 = step2 = step3 = step4 = step5 = 0;
}

int EDJoin::minEditErrors(QGramList qGramList, int begin, int end) const{
	int cnt = 0;
	int loc = -1;
	qGramList.arrange_by_loc();
	std::vector<QGram*> list = qGramList.getGramList();
	if(end < 0)end = list.size();
	for(int i = begin; i < end && i < list.size(); i++){
		if(list[i]->getLoc() > loc){
			cnt++;
			loc = list[i]->getLoc()+q-1;
		}
	}
	return cnt;
}


int EDJoin::calcPrefixLen(QGramList qGramList) const{
	int left = t+1;
	int right = q*t+1;
	while(left < right){
		int mid = (left+right)/2;
		int err = minEditErrors(qGramList, 0, mid);
		if(err <= t) left = mid+1;
		else right = mid;
	}
	return left;
}

int EDJoin::sumRightErrors(int pos, QGramList qGramList) const{
	int cnt = 0;
	int loc = -1;
	qGramList.arrange_by_loc();
	std::vector<QGram*> list = qGramList.getGramList();
	for(int i = 0; i < list.size(); i++){
		if(list[i]->getLoc() < pos){
			continue;
		}
		else{
			if(list[i]->getLoc() > loc){
				cnt++;
				loc = list[i]->getLoc()+q-1;
			}
		}
	}
	return cnt;
}

int EDJoin::contentFilter(std::string ss, std::string st, QGramList qGramList) const{
	int j = 0;
	int i = 1;
	qGramList.arrange_by_loc();
	std::vector<QGram*> list = qGramList.getGramList();
	if(list.size() == 0)return 0;
	while(i < list.size()){
		if(list[i]->getLoc()-list[i-1]->getLoc() > 1){
			int e = l1Distance(ss,st,list[j]->getLoc(), list[i-1]->getLoc()+q-1)
				+ sumRightErrors(list[i-1]->getLoc()+q, qGramList);
			if(e > 2*t) return 2*t+1;
			j = i;
		}
		i++;
	}
	return l1Distance(ss,st,list[j]->getLoc(), list[i-1]->getLoc()+q-1)
		+ sumRightErrors(list[i-1]->getLoc()+q, qGramList);
}

int EDJoin::l1Distance(std::string ss, std::string st, int lo, int hi) const{
	std::map<char, int> hs = freqHistogram(ss, lo, hi);
	std::map<char, int> ht = freqHistogram(st, lo, hi);
	std::set<char> tmpset;
	std::map<char, int>::iterator iter;
	int sum = 0;
	for(iter = hs.begin(); iter != hs.end(); ++iter){
		char key = iter->first;
		if(ht.find(key) == ht.end()){
			sum += hs[key];
		}
		else{
			sum += abs(hs[key] - ht[key]);
		}
		tmpset.insert(key);
	}

	for(iter = ht.begin(); iter != ht.end(); ++iter){
		char key = iter->first;
		if(tmpset.find(key) != tmpset.end()){
			continue;
		}
		else{
			sum += ht[key];
		}
	}
	return sum;
}

std::map<char, int> EDJoin::freqHistogram(std::string s, int start, int end) const{
	std::map<char, int> tmpmap;
	for(int i=start; i<=end && i < s.size(); i++){
		if(tmpmap.find(s[i]) == tmpmap.end()){
			tmpmap[s[i]] = 1;
		}
		else tmpmap[s[i]] = tmpmap[s[i]] + 1;
	}
	return tmpmap;
}

void EDJoin::verify(QGramList x, std::set<QGramList> A){
	std::set<QGramList>::iterator iter = A.begin();
	for(; iter != A.end(); ++iter){
		QGramList y = *iter;
		step1++;
		std::pair<QGramList, int> retPair = compareQGrams(x,y);
		int e1 = retPair.second;
		QGramList Q = retPair.first;
		if(e1 <= q*t){
			step2++;
			int e2 = minEditErrors(Q);
			if(e2 <= t){
				step3++;
				int e3 = contentFilter(x.getText(), y.getText(), Q);
				if(e3 <= 2*t){
					step4++;
					int ed = editDistance(x.getText(), y.getText());
					if(ed <= t){
						step5++;
						std::pair<int, int> item;
						if(x.getId() < y.getId()){
							item.first = x.getId();
							item.second = y.getId();
							results.push_back(item);
						}
						else if(x.getId() > y.getId()){
							item.first = y.getId();
							item.second = x.getId();
							results.push_back(item);
						}
					}
				}
			}
		}
	}
}

int EDJoin::minimum (int a, int b, int c) const{
	int mi;
	mi = a;
	if (b < mi) {
		mi = b;
	}
	if (c < mi) {
		mi = c;
	}
	return mi;
}
int EDJoin::editDistance(std::string s1, std::string s2) const
{ 
	int i, iCrt, iPre, j;
	int n = s1.size();
	int m = s2.size();
	if (n == 0) return m;
	if (m == 0) return n;
	int d[2][m + 1];
	for (j = 0; j <= m; j++)
		d[0][j] = j;
	iCrt = 1;
	iPre = 0;
	for (i = 1; i <= n; i++) {
		d[iCrt][0] = i;
		for (j = 1; j <= m; j++)
			d[iCrt][j] = minimum(d[iPre][j] + 1, 
					 d[iCrt][j - 1] + 1, 
					 d[iPre][j - 1] + (s1[i - 1] == s2[j - 1] ? 0 : 1));
		iPre = !iPre;
		iCrt = !iCrt;
	}
	return d[iPre][m]; 
}


std::pair<QGramList, int> EDJoin::compareQGrams(QGramList x, QGramList y){
	int i = 0;
	int j = 0;
	int e = 0;
	x.arrange_by_str();
	y.arrange_by_str();
	std::vector<QGram*> list;
	std::vector<QGram*> xlist = x.getGramList();
	std::vector<QGram*> ylist = y.getGramList();
	while(i < xlist.size() && j < ylist.size()){
		if(xlist[i]->getToken() == ylist[j]->getToken()){
			if(abs(xlist[i]->getLoc()-ylist[j]->getLoc()) <= t){
				i++;
				j++;
			}
			else{
				if(xlist[i]->getLoc() < ylist[j]->getLoc()){
					if(i == 0 ||
					   j == 0 ||
					   xlist[i]->getToken() != xlist[i-1]->getToken()||
					   xlist[i]->getToken() != ylist[j-1]->getToken()||
					   abs(xlist[i]->getLoc() - ylist[j-1]->getLoc())> t){
						list.push_back(xlist[i]);
					}
					e++;
					i++;
				}
				else{
					j++;
				}
			}
		}
		else{
			if(xlist[i]->getToken() < ylist[j]->getToken()){
				if(i == 0 ||
				   j == 0 ||
				   xlist[i]->getToken() != xlist[i-1]->getToken()||
				   xlist[i]->getToken() != ylist[j-1]->getToken()||
				   abs(xlist[i]->getLoc() - ylist[j-1]->getLoc())> t){
					list.push_back(xlist[i]);
				}
				e++;
				i++;
			}
			else{
				j++;
			}
		}
	}
	while(i < xlist.size()){
		if(i == 0 ||
		   j == 0 ||
		   xlist[i]->getToken() != xlist[i-1]->getToken()||
		   xlist[i]->getToken() != ylist[j-1]->getToken()||
		   abs(xlist[i]->getLoc() - ylist[j-1]->getLoc())> t){
			list.push_back(xlist[i]);
		}
		e++;
		i++;
	}
	QGramList qGramList(list, &tf);
	std::pair<QGramList, int> retPair(qGramList, e);
	return retPair;
}

void EDJoin::simjoin(char* file){
	for(int i=0; i<words.size(); i++){
		std::set<QGramList> A;
		QGramList x = words[i];
		int prefix = calcPrefixLen(x);
		std::vector<QGram*> xlist = x.getGramList();
		for(int j=0; j<prefix && j<xlist.size(); j++){
			std::string w = xlist[j]->getToken();
			int loc = xlist[j]->getLoc();
			if(invertedList.find(w) != invertedList.end()){
				std::vector<InvertedListItem> iList = invertedList[w];
				for(int k=0; k<iList.size(); k++){
					QGramList y = iList[k].getQGramList();
					std::vector<QGram*> ylist = y.getGramList();
					if((ylist.size() >= xlist.size() -t) &&
					   abs(loc-iList[k].getLoc()) <= t){
						A.insert(y);
					}

				}
			}
			else invertedList[w] = std::vector<InvertedListItem>();
			InvertedListItem item(loc, x);
			invertedList[w].push_back(item);
		}
		verify(x, A);
	}

	calcSingles();
	writeToFile(file);
}

bool EDJoin::contains(InvertedListItem item, std::vector<InvertedListItem> list){
	bool flag = false;
	for(int i=0; i<list.size(); i++){
		if(item.getLoc() == list[i].getLoc() &&
		   item.getQGramList().getId() == list[i].getQGramList().getId()){
			flag = true;
			break;
		}
	}
	return flag;
}

void EDJoin::calcSingles(){
	if(t <= 0) return;
	for(int i=0; i<singles.size(); i++){
		for(int j = i+1; j < singles.size(); j++){
			std::pair<int, int> item;
			QGramList x = singles[i];
			QGramList y = singles[j];
			if(x.getId() < y.getId()){
				item.first = x.getId();
				item.second = y.getId();
				results.push_back(item);
			}
			else if(x.getId() > y.getId()){
				item.first = y.getId();
				item.second = x.getId();
				results.push_back(item);
			}
		}
	}
}

void EDJoin::readFromFile(char* file){
	std::ifstream infile(file);
	std::string line;
	int id = 1;
	while(infile.good()){
		getline(infile, line);
		std::string tmpline = "";
		for(int i=0; i<line.size(); i++){
			if(line[i] != '\r')tmpline += line[i];
		}
		line = tmpline;
		if(line.empty())continue;
		QGramList qGramList(line, id, q, &tf);
		words.push_back(qGramList);
		if(line.size() == 1)singles.push_back(qGramList);
		id++;
	}
	infile.close();
	for(int i=0; i<words.size(); i++){
		words[i].arrange_by_idf();
	}
	sort(words.begin(), words.end(), CompareQGramList());
}


void EDJoin::writeToFile(char* file){
	sort(results.begin(), results.end(), CompareResults());
	std::ofstream outfile(file);
	for(int i=0; i<results.size(); i++){
		std::pair<int, int> item = results[i];
		outfile << item.first << "," << item.second << std::endl;
	}
	outfile.close();
}

bool CompareQGramList::operator()(QGramList x, QGramList y){
	return x.getText().size() < y.getText().size();
}

bool CompareResults::operator()(std::pair<int,int> x, std::pair<int, int> y){
	if(x.first < y.first){
		return true;
	}
	else if(x.first == y.first){
		return x.second < y.second;
	}
	else return false;
}


void EDJoin::printTF(){
	std::map<std::string, int>::iterator iter = tf.begin();
	for(; iter != tf.end(); ++iter){
		std::cout<<iter->first<<" "<<iter->second<<std::endl;
	}
}

void EDJoin::printInvertedList(){
	std::map<std::string, std::vector<InvertedListItem> >::iterator iter = invertedList.begin();
	for(; iter != invertedList.end(); ++iter){
		std::vector<InvertedListItem> list = iter->second;
		std::cout<<iter->first<<":";
		for(int i=0; i<list.size(); i++){
			std::cout<<"("<<list[i].getQGramList().getText()<<","<<list[i].getLoc()<<") ";
		}
		std::cout<<std::endl;
	}
}
