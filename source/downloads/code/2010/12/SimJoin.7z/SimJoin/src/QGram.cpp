/*
 * QGram.cpp
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#include "QGram.h"

QGram::QGram(int _loc, std::string _token){
    loc = _loc;
    token = _token;
}

int QGram::getLoc() const{
    return loc;
}

std::string QGram::getToken() const{
    return token;
}