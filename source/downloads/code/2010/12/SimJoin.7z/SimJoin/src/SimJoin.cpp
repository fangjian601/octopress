/*
 * SimJoin.cpp
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#include <iostream>

#include <cstring>
#include "EDJoin.h"
#include "PPJoin.h"


int main(int argc, char* argv[]){
	if(argc < 5){
		std::cerr<<"Invalid Options"<<std::endl;
		std::cerr<<"Usage: sj path1 path2 [ed|jc] t [q]"<<std::endl;
	}
	else{
		char* inputfile = argv[1];
		char* outputfile = argv[2];
		char* func = argv[3];
		if(strcmp(func, "ed") == 0 && argc >= 6){
			int t = atoi(argv[4]);
			int q = atoi(argv[5]);
			EDJoin edjoin(inputfile, t, q);
			edjoin.simjoin(outputfile);
		}
		else if(strcmp(func, "jc") == 0){
			double t = atof(argv[4]);
			PPJoin ppjoin(inputfile,t,true);
			ppjoin.simjoin(outputfile);
		}
		else{
			std::cerr<<"Invalid Options"<<std::endl;
			std::cerr<<"Usage: SimJoin path1 path2 [ed|jc] t [q]"<<std::endl;
		}
	}
}
