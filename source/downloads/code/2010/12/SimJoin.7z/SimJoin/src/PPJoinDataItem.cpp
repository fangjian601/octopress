#include <algorithm>
#include <sstream>

#include "PPJoinDataItem.h"


PPJoinDataItem::PPJoinDataItem(int _id, std::string _text, std::map<std::string, int>* _df, char* _token){
	id = _id;
	text = _text;
	token = _token;
	df = _df;
	buildTokenList();
}

int PPJoinDataItem::getId() const{
	return id;
}

std::string PPJoinDataItem::getText() const{
	return text;
}

std::vector<std::string> PPJoinDataItem::getTokenList() const{
	return tokenList;
}

std::set<std::string> PPJoinDataItem::getTokenSet() const{
	return tokenSet;
}

unsigned int PPJoinDataItem::size() const{
	return tokenList.size();
}

void PPJoinDataItem::buildTokenList(){
	char* p;
	char * cstr = new char[text.size() + 1];
	strcpy(cstr, text.c_str());
	p = strtok(cstr, token);
	while(p != NULL){
		if(strcmp(p, "") == 0){
			p = strtok(NULL, token);
			continue;
		}
		else{
			std::string item(p);
			if(tokenSet.find(item) == tokenSet.end())tokenList.push_back(item);
			tokenSet.insert(item);
			p = strtok(NULL, token);
		}
	}

	//buildTokenSet();
	buildTokenDf();
}

void PPJoinDataItem::buildTokenSet(){
	for(int i=0; i<tokenList.size(); i++){
		tokenSet.insert(tokenList[i]);
	}
}


void PPJoinDataItem::buildTokenDf(){
	std::set<std::string>::iterator iter = tokenSet.begin();
	for(; iter != tokenSet.end(); ++iter){
		std::string item = *iter;
		if(df->find(item) == df->end()){
			(*df)[item] = 1;
		}
		else{
			(*df)[item] = (*df)[item] + 1;
		}
	}
}

bool PPJoinDataItem::compare(PPJoinDataItem item , int xi, int yi){
	return (item.tokenList[yi] == tokenList[xi]);
}


bool PPJoinDataItem::compare_by_df(std::string x, std::string y){
	int dfx,dfy;
	if(df->find(x) == df->end())dfx = 0;
	else dfx = (*df)[x];
	
	if(df->find(y) == df->end())dfy = 0;
	else dfy = (*df)[y];

	if(dfx < dfy)return true;
	else if(dfx == dfy)return x < y;
	else return false;
}

void PPJoinDataItem::arrange_by_df(){
	sort(tokenList.begin(), tokenList.end(), ComparePPJoinToken(this));
}

double PPJoinDataItem::jaccard(const PPJoinDataItem& x, const PPJoinDataItem& y){
	double a = (double)((x*y).size());
	double b = (double)((x+y).size());
	return a/b;
}

std::string PPJoinDataItem::operator[](int index) const{
	return tokenList[index];
}

bool operator<(const PPJoinDataItem& x, const PPJoinDataItem& y){
	return x.getId() < y.getId();
}

std::vector<std::string> operator+(const PPJoinDataItem& x, const PPJoinDataItem& y){
	std::set<std::string> Sx = x.getTokenSet();
	std::set<std::string> Sy = y.getTokenSet();
	std::vector<std::string> ret;
	std::set_union(Sx.begin(), Sx.end(), Sy.begin(), Sy.end(), back_inserter(ret));
	return ret;
}

std::vector<std::string> operator*(const PPJoinDataItem& x, const PPJoinDataItem& y){
	std::set<std::string> Sx = x.getTokenSet();
	std::set<std::string> Sy = y.getTokenSet();
	std::vector<std::string> ret;
	std::set_intersection(Sx.begin(), Sx.end(), Sy.begin(), Sy.end(), back_inserter(ret));
	return ret;
}

bool operator==(const PPJoinDataItem& x, const PPJoinDataItem& y){
	return (x.getId() == y.getId());
}

std::ostream& operator<<(std::ostream& out, const PPJoinDataItem& item){
	std::stringstream sstr;
	sstr << item.getId()<<"# ";
	for(int i=0; i<item.size(); i++){
		sstr << "(" << item[i] << "," << (*item.df)[item[i]] << ") ";
	}
	out << sstr.str();
	return out;
}

ComparePPJoinToken::ComparePPJoinToken(PPJoinDataItem* _dataItem){
	dataItem = _dataItem;
}

bool ComparePPJoinToken::operator()(std::string x, std::string y){
	return dataItem->compare_by_df(x,y);
}
