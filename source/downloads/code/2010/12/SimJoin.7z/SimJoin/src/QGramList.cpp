/*
 * QGramList.cpp
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#include <set>
#include <algorithm>
#include <sstream>

#include "QGramList.h"



QGramList::QGramList(std::string _text, int _id, int _q, std::map<std::string, int>* _tf){
	text = _text;
	id   = _id;
	q    = _q;
	tf  = _tf;
	buildList();
	buildSet();
	setIdf();
}

QGramList::QGramList(std::vector<QGram*> _gramList, std::map<std::string, int>* _tf){
	gramList = _gramList;
	tf = _tf;
}

QGramList::QGramList(const QGramList& qGramList){
	text = qGramList.text;
	id = qGramList.id;
	q = qGramList.q;
	tf = qGramList.tf;
	gramList = qGramList.gramList;
	
}

void QGramList::buildList(){
	std::string temtext = std::string(q - 1, PREFIXCHAR) + text + std::string(q - 1, SUFFIXCHAR);
	if(temtext.size() <= q){
		QGram* qGram = new QGram(0, temtext);
		gramList.push_back(qGram);
	}
	else{
		int loc = 0;
		for(int i=0; i<temtext.size()- q + 1; i++){
			QGram* qGram = new QGram(loc, temtext.substr(i,q));
			gramList.push_back(qGram);
			loc++;
		}
	}

}

void QGramList::buildSet(){
	for(int i=0; i<gramList.size(); i++){
		gramSet.insert(gramList[i]->getToken());
	}
}

void QGramList::setIdf(){
	std::set<std::string>::iterator iter = gramSet.begin();
	for(; iter != gramSet.end(); ++iter){
		std::string str = *iter;
		if(tf->find(str) == tf->end()){
			(*tf)[str] = 1;
		}
		else{
			(*tf)[str] = (*tf)[str] + 1;
		}
	}
}


bool QGramList::compare_by_idf(QGram* x, QGram* y) const{
	int tf_x = 0;
	int tf_y = 0;
	if(tf->find(x->getToken()) != tf->end()){
		tf_x = (*tf)[x->getToken()];
	}
	if(tf->find(y->getToken()) != tf->end()){
		tf_y = (*tf)[y->getToken()];
	}
	if(tf_x < tf_y) return true;
	else if(tf_x == tf_y){
		if(x->getLoc() <= y->getLoc())return true;
		else return false;
	}
	else return false;

}

bool QGramList::compare_by_loc(QGram* x, QGram* y) const{
	return (x->getLoc() <= y->getLoc());
}

int QGramList::getId() const{
	return id;
}

std::string QGramList::getText() const{
	return text;
}


std::vector<QGram*> QGramList::getGramList() const{
	return gramList;
}

void QGramList::arrange_by_idf(){
	sort(gramList.begin(), gramList.end(), CompareIdf(this));
}

void QGramList::arrange_by_loc(){
	sort(gramList.begin(), gramList.end(), CompareLoc(this));
}


void QGramList::arrange_by_str(){
	sort(gramList.begin(), gramList.end(), CompareStr());
}


void QGramList::insert_blank(int prefix){
	if(prefix > gramList.size()){
		for(int i=gramList.size(); i<prefix; i++){
			std::string gram(q,224);
			gramList.push_back(new QGram(i,gram));
			text = text+gram;
		}
	}
}

std::ostream& operator<<(std::ostream& out, const QGramList& qGramList){
	std::vector<QGram*> list = qGramList.getGramList();
	for(int i=0; i<list.size(); i++){
		std::string token = list[i]->getToken();
		int loc = list[i]->getLoc();
		std::stringstream sstr;
		sstr << "(" << token << "," << loc << ") ";
		out << sstr.str();
	}
	return out;
}

bool operator<(QGramList x, QGramList y){
	return x.getId() < y.getId();
}

CompareIdf::CompareIdf(QGramList* _qGramList){
	qGramList = _qGramList;
}

bool CompareIdf::operator()(QGram* x, QGram* y){
	return qGramList->compare_by_idf(x,y);
}

CompareLoc::CompareLoc(QGramList* _qGramList){
	qGramList = _qGramList;
}

bool CompareLoc::operator()(QGram* x, QGram* y){
	return qGramList->compare_by_loc(x,y);
}

bool CompareStr::operator()(QGram* x, QGram* y){
	if(x->getToken() < y->getToken()) return true;
	else if(x->getToken() == y->getToken()) return x->getLoc() <  y->getLoc();
	else return false;
}

