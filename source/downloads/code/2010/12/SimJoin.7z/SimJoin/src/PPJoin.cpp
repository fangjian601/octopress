#include <cstring>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <limits>


#include "PPJoin.h"

PPJoin::PPJoin(char* file, double _t, int _maxdepth , bool _ppjoinplus, bool _useSeekPositionOnSuffixFiltering){
	t = _t;
	maxdepth = _maxdepth;
	useSeekPositionOnSuffixFiltering = _useSeekPositionOnSuffixFiltering;
	ppjoinplus = _ppjoinplus;
	readFromFile(file);
}

void PPJoin::readFromFile(char* file){
	std::ifstream infile(file);
	std::string line;
	int id = 1;
	while(infile.good()){
		getline(infile, line);
		std::string tmpline = "";
		for(int i=0; i<line.size(); i++){
			if(line[i] != '\r') tmpline += line[i];
		}
		line = tmpline;
		if(line.empty())continue;
		PPJoinDataItem data(id,line,&df);
		dataSet.push_back(data);
		id++;
	}

	for(int i=0; i<dataSet.size(); i++){
		dataSet[i].arrange_by_df();
	}

	sort(dataSet.begin(), dataSet.end(), CompareDataSet());

	infile.close();
}

double PPJoin::filter(PPJoinDataItem x, PPJoinDataItem y, int xstart, int ystart, int xend, int yend, double hmax, int depth){
	std::vector<std::string> vx = copyOfRange(x.getTokenList(),xstart,xend);
	std::vector<std::string> vy = copyOfRange(y.getTokenList(),ystart,yend);
	return suffixFilter(vx,vy,hmax,depth);
}
double PPJoin::suffixFilter(std::vector<std::string> wx, std::vector<std::string> wy, double hmax, int depth){
	if(depth > maxdepth)return abs(wx.size() - wy.size());
	int xlen = wx.size();
	int ylen = wy.size();
	if(xlen <= 0 || ylen <= 0)
		return hmax + 1;
	int mid = (int)ceil(ylen / 2.0);
	std::string w = wy[mid];
	double o = (hmax - abs(xlen - ylen)) / 2.0;
	int oL = xlen < ylen ? 1 : 0;
	int oR = xlen < ylen ? 0 : 1;
	//partitioning(y)
	Partition yp = partition(wy, w, mid, mid);
	//partitioning(x)
	int xpl = (int)(mid - o - abs(xlen - ylen) * oL);
	int xpr = (int)(mid + o + abs(xlen - ylen) * oR);
	Partition xp =partition(wx,w,xpl < 0 ? 0 : xpl, xpr >= wx.size() ? wx.size() - 1 : xpr);
	int diff = xp.getDiff() > 0 ||  yp.getDiff() > 0 ? 1 : 0 ;
	
	if(yp.getF() == 0  || xp.getF() == 0)
		return hmax + 1;
	
	//examination
	double h =abs(xp.getSl().size() - yp.getSl().size()) + abs(xp.getSr().size() - yp.getSr().size()) + diff;
	if(h > hmax){
		return h;
	}
	
	double hlmax = hmax - abs(xp.getSr().size() - yp.getSr().size()) - diff;
	double hl = suffixFilter(xp.getSl(),yp.getSl(),hlmax < 0.0 ? 0.0 : hlmax,depth + 1);
	h = hl + abs(xp.getSr().size() - yp.getSr().size()) + diff;
	
	if(h <= hmax){
		double hrmax = hmax - hl - diff;
		double hr = suffixFilter(xp.getSr(), yp.getSr(),  hrmax < 0.0 ? 0.0 : hrmax, depth + 1);
		return hl + hr + diff;
	}
	else{
		return h;
	}
}

Partition PPJoin::partition(std::vector<std::string> s, std::string w, int l, int r){
	std::vector<std::string> sl, sr;
	if(l > r || r < l)
		return Partition(sl, sr, 0, 1);
	
	int p = -1;
	if(l == r){
		p = l;
	}
	else{
		for(int i = l ; i < r ; i++){
			std::string item = s[i];
			if(item == w){
				p = i;
				break;
			}
		}
	}
	if(p <= 0) return Partition(sl, sr, 0, 1);
	
	int diff = 0;
	sl = copyOfRange(s, 0, p -1);
	if(s[p] == w){
		sr = copyOfRange(s, p + 1, s.size());
		diff = 0;
	}
	else{
		sr = copyOfRange(s, p , s.size());
		diff = 1;
	}

	return Partition(sl, sr, 1, diff);
}

std::vector<std::string> PPJoin::copyOfRange(std::vector<std::string> s, int start, int end){
	std::vector<std::string> ret;
	for(int i=start; i<end && i<s.size(); i++){
		ret.push_back(s[i]);
	}
	return ret;
}

bool PPJoin::verify(PPJoinDataItem x, PPJoinDataItem y, int i, int j, double a){
	double score = 0.0;
	if(i < j){
		int ubound = x.size() - i;
		if(ubound >= a){
			score = PPJoinDataItem::jaccard(x,y);
		}
	}else{
		int ubound = y.size() - j;
		if(ubound >= a){
			score = PPJoinDataItem::jaccard(x,y);
		}
	}
	
	return score >= t;
}

void PPJoin::verify(PPJoinDataItem ix, std::map<PPJoinDataItem, int> A, std::map<PPJoinDataItem, double> aMap){
	int xlen = ix.size();
	int p = (int)(xlen - ceil(t * xlen) + 1);
	std::map<PPJoinDataItem, int>::iterator iter = A.begin();
	for(; iter != A.end(); ++iter){
		if(iter->second <= 0)continue;
		PPJoinDataItem iy = iter->first;
		int o = iter->second;
		int ylen = iy.size();
		double a = aMap[iy];
		std::pair<int, int> r = getPrefix(ix,iy,p,a);
		if(r.first == -1 || r.second == -1)continue;
		int px = r.first;
		int py = r.second;
		double score = 0.0;
		if(px < py){
			int ubound = xlen - px;
			if(ubound >= a){
				score = PPJoinDataItem::jaccard(ix,iy);
			}
		}
		else{
			int ubound = ylen - py;
			if(ubound >= a){
				score = PPJoinDataItem::jaccard(ix,iy);
			}
		}
		if(score >= t)addResult(ix, iy);
	}
}

void PPJoin::addResult(PPJoinDataItem x, PPJoinDataItem y){
	std::pair<int, int> p;
	if(x.getId() < y.getId()){
		p.first = x.getId();
		p.second = y.getId();
		results.push_back(p);
	}
	else if(x.getId() > y.getId()){
		p.first = y.getId();
		p.second = x.getId();
		results.push_back(p);
	}
}

std::pair<int,int> PPJoin::getPrefix(PPJoinDataItem ix, PPJoinDataItem iy, int p, int a){
	int xlen = ix.size();
	int ylen = iy.size();
	std::pair<int, int> result(-1,-1);
	for(int i = 0 ; i < p && i < xlen ; i++){
		for(int j = 0 ; j < p && j < ylen; j++){
			int ubound = 1 + min(xlen - i, ylen - j);
			if(ubound < a){
				break;
			}

			if(ix[i] == iy[j]){
				result.first = i;
				result.second = j;
				break;
			}
		}
		if((result.first > -1 && result.second > -1))
			break;
	}
	return result;
}

void PPJoin::simjoin(char* file){
	for(int src = 0; src < dataSet.size(); src++){
		PPJoinDataItem ix = dataSet[src];
		int xlen = ix.size();
		if(xlen == 0) continue;
		simjoin(ix);
		
	}
	writeToFile(file);
}

void PPJoin::simjoin(PPJoinDataItem ix){
	std::map<PPJoinDataItem, int> A;
	std::map<PPJoinDataItem, double> aMap;
	if(dataSet.size() == 0) return;
	
	int xlen = ix.size();
	if(xlen == 0) return;
	//p ← |x| − (t · |x|) + 1;
	int p = (int)(xlen - ceil(t * xlen) + 1);
	double a = 0.0;
	for(int i = 0; i < p ;i++){
		std::string w = ix[i];
		if(invertedMap.find(w) != invertedMap.end()){
			std::vector<InvertedListType> iList = invertedMap[w];
			for(int k=0; k<iList.size(); k++){
				PPJoinDataItem iy = iList[k].first;
				int j = iList[k].second;
				int ylen = iy.size();
				if(ylen >= (t*xlen)){
					a = ceil((t / (1 + t)) * (xlen + ylen));
					int ubound = 1 + min(xlen - i, ylen - j);
					if(A.find(iy) == A.end())A[iy] = 0;
					if(A[iy]+ubound >= a){
						if(!ppjoinplus)A[iy] = A[iy] + 1;
						else{
							if(A[iy] == 0){
								std::pair<int,int> prefix = getPrefix(ix, iy, p, a);
								int prefixI = prefix.first;
								int prefixJ = prefix.second;
								double hmax = xlen + ylen - 2 * ceil((t / (1 + t)) * (xlen + ylen)) - (prefixI + prefixJ - 2); 
								double h = filter(ix, iy, prefixI + 1, prefixJ + 1, ix.size(), iy.size(), hmax, 1);
								if(h <= hmax)A[iy] = A[iy] + 1;
								else A[iy] = std::numeric_limits<int>::min();
							}
						}
					}
					else{
						A[iy] = 0;					
					}
					aMap[iy] = a;
				}
			}
		}
		else{
			invertedMap[w] = std::vector<InvertedListType>();
		}
		InvertedListType iListItem(ix,i);
		invertedMap[w].push_back(iListItem);
	}
	//std::cout<<"ix: "<<ix<<std::endl;
	//printA(A);
	verify(ix, A, aMap);
	/*
	for(int dist = 0; dist<dataSet.size(); dist++){
		PPJoinDataItem iy = dataSet[dist];
		if(ix.getId() == iy.getId())
			continue;
		if(buf.find(iy.getId()) != buf.end())
			continue;
		int ylen = iy.size();
		if(ylen < (t * xlen) || xlen < (t * ylen))
			continue;
		double a = ceil((t / (1 + t)) * (xlen + ylen));

		int prefixI = -1;
		int prefixJ = -1;
		for(int i = 0 ; i < p && i < xlen ; i++){
			for(int j = 0 ; j < p && j < ylen; j++){
				//std::cout<<"i: "<<i<<" j: "<<j<<std::endl;
				//std::cout<<"ix: "<<ix[i]<<" iy: "<<iy[j]<<std::endl;
				int ubound = 1 + min(xlen - i, ylen - j);
				//std::cout<<"ubound: "<<ubound<<" a: "<<a<<" p: "<<p<<std::endl;
				if(ubound < a){
					break;
				}

				if(ix[i] == iy[j]){
					prefixI = i;
					prefixJ = j;
					break;
				}
			}
			if((prefixI > -1 && prefixJ > -1))
				break;
		}

		if((prefixI <= -1 || prefixJ <= -1))
			continue;
		
		//suffix filtering
		//Hmax = |x| + |y| - 2 * ( ( t / (1 + t) ) * (|x| + |y|) ) - (i + j - 2)
		double hmax = 
			xlen + ylen - 2
			* ceil((t / (1 + t)) * (xlen + ylen))
			- (prefixI + prefixJ - 2); 
		double h = 0;
		if(useSeekPositionOnSuffixFiltering){
			h = filter(ix, iy, prefixI + 1, prefixJ + 1, ix.size(), iy.size(), hmax, 1);
		}else{
			h = filter(ix, iy, 0, 0, ix.size(), iy.size(), hmax, 1);
		}
		if(h < hmax)
			continue;
		//verify
		if(verify(ix, iy, prefixI, prefixJ, a)){
			result.push_back(iy);
		}

	}
	*/

}

void PPJoin::writeToFile(char* file){
	sort(results.begin(), results.end(), ComparePPJoinResults());
	std::ofstream outfile(file);
	for(int i=0; i<results.size(); i++){
		std::pair<int, int> item = results[i];
		outfile << item.first << "," << item.second << std::endl;
	}
	outfile.close();
}

void PPJoin::printA(std::map<PPJoinDataItem, int> A){
	std::map<PPJoinDataItem, int>::iterator iter = A.begin();
	for(; iter != A.end(); ++iter){
		PPJoinDataItem ix = iter->first;
		std::cout<<"("<<ix.getId()<<"#,"<<A[ix]<<") ";
	}
	std::cout<<std::endl;
}

bool ComparePPJoinResults::operator()(std::pair<int,int> x, std::pair<int, int> y){
	if(x.first < y.first){
		return true;
	}
	else if(x.first == y.first){
		return x.second < y.second;
	}
	else return false;
}

bool CompareDataSet::operator()(PPJoinDataItem x, PPJoinDataItem y){
	return x.size() < y.size();
}

int PPJoin::min(int x, int y){
	if (x < y)return x;
	else return y;
}
