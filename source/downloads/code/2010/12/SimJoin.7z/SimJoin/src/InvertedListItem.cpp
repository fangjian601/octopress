/*                                                                                                                    
 * InvertedListItem.cpp
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#include "InvertedListItem.h"

InvertedListItem::InvertedListItem(int _loc, const QGramList& _qGramList){
	loc = _loc;
	qGramList = QGramList(_qGramList);
}

int InvertedListItem::getLoc() const{
	return loc;
}

QGramList InvertedListItem::getQGramList() const{
	return qGramList;
}

