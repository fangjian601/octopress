#!/usr/bin/python
import sys

a = {}

if len(sys.argv) < 3:
	print "Usage: python valid.py check_file correct_file"
else:	
	afile = sys.argv[1]
	bfile = sys.argv[2]

	fa = open(afile, "r")
	alines = fa.readlines()
	for line in alines:
		line = line.replace("\n", "").replace("\r", "")
		if line != "":
			a[line] = 1
	fa.close()

	fb = open(bfile, "r")
	blines = fb.readlines()
	for line in blines:
		line = line.replace("\n", "").replace("\r", "")
		if line != "" and not a.has_key(line):
			print line
	fb.close()		


