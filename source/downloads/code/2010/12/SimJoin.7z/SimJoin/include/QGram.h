/*
 * QGram.h
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#ifndef QGRAM_H_
#define QGRAM_H_

#include <string>

class QGram{
public:
	QGram(int _loc, std::string _token);
	int getLoc() const;
	std::string getToken() const;
private:
	int loc;
	std::string token;
};


#endif /* QGRAM_H_ */
