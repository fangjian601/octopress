/*
 * EDJoin.h
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#ifndef EDJOIN_H_
#define EDJOIN_H_

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <map>

#include "QGramList.h"
#include "QGram.h"
#include "InvertedListItem.h"

class EDJoin{
public:
	EDJoin(char* file, int _t, int _q);
	void simjoin(char* file);

private:
	int   minimum (int a, int b, int c) const;
	int   minEditErrors(QGramList qGramList, int begin = 0, int end = -1) const;
	int   calcPrefixLen(QGramList qGramList) const;
	int   sumRightErrors(int pos, QGramList qGramList) const;
	int   contentFilter(std::string ss, std::string st, QGramList qGramList) const;
	int   l1Distance(std::string ss, std::string st, int lo, int hi) const;
	std::map<char, int>  freqHistogram(std::string s, int start, int end) const;
	void  verify(QGramList qGramList, std::set<QGramList> A);
	int   editDistance(std::string x, std::string y) const;
	std::pair<QGramList, int> compareQGrams(QGramList x, QGramList y);
	bool contains(InvertedListItem item, std::vector<InvertedListItem> list);	
	void calcSingles();
	void readFromFile(char* file);
	void writeToFile(char* file);

	void printTF();
	void printInvertedList();

	int q;
	int t;
	std::vector<QGramList> words;
	std::vector<QGramList> singles;
	std::map<std::string, std::vector<InvertedListItem> > invertedList;
	std::vector<std::pair<int, int> > results;
	std::map<std::string, int> tf;

	int step1,step2,step3,step4,step5;
};

class CompareQGramList{
public:
	bool operator()(QGramList x, QGramList y);
};

class CompareResults{
public:
	bool operator()(std::pair<int,int>, std::pair<int, int>);
};

#endif /* EDJOIN_H_ */
