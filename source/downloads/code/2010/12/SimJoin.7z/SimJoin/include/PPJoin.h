

#include <string>
#include <vector>
#include <set>
#include <map>

#include "PPJoinDataItem.h"

#define MINIMUM_MAXDEPTH 3




class Partition{
public:
	Partition(std::vector<std::string> _sl, 
		   std::vector<std::string> _sr, 
		   int _f, int _diff) : sl(_sl), sr(_sr), f(_f), diff(_diff){}
	std::vector<std::string> getSl() const{return sl;}
	std::vector<std::string> getSr() const{return sr;}
	int getF() const{return f;}
	int getDiff() const{return diff;}
private:
	std::vector<std::string> sl;
	std::vector<std::string> sr;
	int f;
	int diff;
};

class PPJoin{
public:
	PPJoin(char* file, double _t, int _maxdepth = MINIMUM_MAXDEPTH, bool _ppjoinplus = false, bool _useSeekPositionOnSuffixFiltering = true);
	void simjoin(char* file);
private:

	typedef std::pair<PPJoinDataItem, int> InvertedListType;

	void readFromFile(char* file);
	void writeToFile(char* file);
	
	bool verify(PPJoinDataItem x, PPJoinDataItem y, int i, int j, double a);
	void verify(PPJoinDataItem ix, std::map<PPJoinDataItem, int> A, std::map<PPJoinDataItem, double> aMap);
	void addResult(PPJoinDataItem x, PPJoinDataItem y);
	void simjoin(PPJoinDataItem ix);
	double filter(PPJoinDataItem x, PPJoinDataItem y, int xstart, int ystart, int xend, int yend, double hmax, int depth);
	double suffixFilter(std::vector<std::string> wx, std::vector<std::string> wy, double hmax, int depth);
	Partition partition(std::vector<std::string> s, std::string w, int l, int r);
	std::vector<std::string> copyOfRange(std::vector<std::string> s, int start, int end);
	int min(int x, int y);
	void printA(std::map<PPJoinDataItem, int> A);
	std::pair<int,int> getPrefix(PPJoinDataItem ix, PPJoinDataItem iy, int p, int a);
	
	double t;
	bool useSeekPositionOnSuffixFiltering;
	bool ppjoinplus;
	std::vector<PPJoinDataItem> dataSet;
	std::map<std::string, int> df;
	std::vector<std::pair<int, int> > results;
	std::map<std::string, std::vector<InvertedListType> > invertedMap;

	int maxdepth;
};

class CompareDataSet{
public:
	bool operator()(PPJoinDataItem x, PPJoinDataItem y);
};

class ComparePPJoinResults{
public:
	bool operator()(std::pair<int,int>, std::pair<int, int>);
};

