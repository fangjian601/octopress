/*
 * QGramList.h
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#ifndef QGRAMLIST_H_
#define QGRAMLIST_H_

#include <string>
#include <vector>
#include <map>
#include <set>

#include "QGram.h"

class QGramList{
public:
	QGramList(){};
	QGramList(std::string _text, int _id, int _q, std::map<std::string, int>* _tf);
	QGramList(std::vector<QGram*> _gramList, std::map<std::string, int>* _tf);
	QGramList(const QGramList& qGramList);
	std::string getText() const;
	int getId() const;
	std::vector<QGram*> getGramList() const;
	void arrange_by_idf();
	void arrange_by_loc();
	void arrange_by_str();
	bool compare_by_loc(QGram* x, QGram* y) const;
	bool compare_by_idf(QGram* x, QGram* y) const;
	void insert_blank(int prefix);
	friend bool operator<(QGramList x, QGramList y);
	friend std::ostream& operator<<(std::ostream& out, const QGramList&);
private:
	void buildList();
	void buildSet();
	void setIdf();
	std::string text;
	int id;
	int q;
	std::vector<QGram*> gramList;
	std::map<std::string, int>* tf;
	std::set<std::string> gramSet;
	static const char PREFIXCHAR = 156; // pound
	static const char SUFFIXCHAR = 190; // yen
};

class CompareIdf{
public:
	CompareIdf(QGramList* _qGramList);
	bool operator()(QGram* x, QGram* y);
private:
	QGramList* qGramList;
};

class CompareLoc{
public:
	CompareLoc(QGramList* _qGramList);
	bool operator()(QGram* x, QGram* y);
private:
	QGramList* qGramList;
};

class CompareStr{
public:
	bool operator()(QGram* x, QGram* y);
};
#endif /* QGRAMLIST_H_ */
