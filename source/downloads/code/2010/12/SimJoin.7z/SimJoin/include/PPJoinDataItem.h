#include <string>
#include <vector>
#include <cstring>
#include <iostream>
#include <map>
#include <set>


class PPJoinDataItem{
public:
	PPJoinDataItem(int _id, std::string _text, std::map<std::string, int>* _df, char* _token = " \t:.,;");
	int getId() const;
	std::string getText() const;
	std::vector<std::string> getTokenList() const;
	std::set<std::string> getTokenSet() const;
	unsigned int size() const;
	static double jaccard(const PPJoinDataItem& x, const PPJoinDataItem& y);
	bool compare(PPJoinDataItem item , int xi, int yi);
	bool compare_by_df(std::string x, std::string y);
	void arrange_by_df();
	std::string operator[](int index) const;
	friend bool operator<(const PPJoinDataItem& x, const PPJoinDataItem& y);
	friend std::vector<std::string> operator+(const PPJoinDataItem& x, const PPJoinDataItem& y);
	friend std::vector<std::string> operator*(const PPJoinDataItem& x, const PPJoinDataItem& y);
	friend bool operator==(const PPJoinDataItem& x, const PPJoinDataItem& y);
	friend std::ostream& operator<<(std::ostream& out, const PPJoinDataItem&);
private:

	void buildTokenList();
	void buildTokenSet();
	void buildTokenDf();

	int id;
	std::string text;
	std::vector<std::string> tokenList;
	std::set<std::string> tokenSet;
	char* token;

	std::map<std::string, int>* df;
};

class ComparePPJoinToken{
public:
	ComparePPJoinToken(PPJoinDataItem* _dataItem);
	bool operator()(std::string x, std::string y);
private:
	PPJoinDataItem* dataItem;
};
