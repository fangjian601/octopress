/*
 * InvertedListItem.h
 *
 *  Created on: 2010-11-29
 *      Author: frank
 */

#ifndef INVERTEDLISTITEM_H_
#define INVERTEDLISTITEM_H_

#include "QGramList.h"

class InvertedListItem{
public:
	InvertedListItem(int _loc, const QGramList& _qGramList);
	int getLoc() const;
	QGramList getQGramList() const;
private:
	int loc;
	QGramList qGramList;
};


#endif /* INVERTEDLISTITEM_H_ */
